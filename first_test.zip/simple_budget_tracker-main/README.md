simple budget tracker made in python
